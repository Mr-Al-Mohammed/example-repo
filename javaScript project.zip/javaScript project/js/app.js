// Dynamic Navigation
const sections = document.querySelectorAll('section');
const navbar = document.getElementById('navbar');

// sections.forEach((section) => {
//   const li = document.createElement('li');
//   const a = document.createElement('a');
//   const sectionId = section.id;

//   a.textContent = sectionId;
//   a.href = `#${sectionId}`;

//   li.appendChild(a);
//   navbar.appendChild(li);
// });

// Active Section Highlighting
window.addEventListener('scroll', () => {
  const currentPos = window.scrollY;

  sections.forEach((section) => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;

    if (currentPos >= sectionTop - sectionHeight * 0.25 && currentPos < sectionTop + sectionHeight) {
      section.classList.add('active');
    } else {
      section.classList.remove('active');
    }
  });

  const navLinks = navbar.getElementsByTagName('a');
  for (const link of navLinks) {
    const sectionId = link.getAttribute('href').substring(1);
    const section = document.getElementById(sectionId);

    if (section.classList.contains('active')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  }
});
