# My Website

This is a simple website project built with HTML, CSS, and JavaScript.

## Description

This project aims to create a responsive landing page with multiple sections. It includes a dynamic navigation menu that highlights the active section while scrolling. The website is designed to be usable across modern desktop, tablet, and phone browsers.

## Features

- Responsive layout for desktop, tablet, and mobile devices.
- Dynamic navigation menu built using JavaScript.
- Active section highlighting based on scroll position.
- Smooth scrolling behavior when clicking on navigation links.

## Technologies Used

- HTML
- CSS
- JavaScript

## Usage

<!-- 1. Clone the repository:

   ```shell
   git clone https://github.com/your-username/your-repository.git -->

2. Open `index.html` in your browser of choice to view it locally in your preferred web browser.
